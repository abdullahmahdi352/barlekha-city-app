import { useState } from "react";

export default function BarlekhaCityApp() {
  const [search, setSearch] = useState("");
  const [listings, setListings] = useState([
    { name: "Barlekha Hospital", category: "Health", phone: "01700-111222" },
    { name: "Cafe Barlekha", category: "Restaurant", phone: "01700-333444" },
  ]);
  const [newItem, setNewItem] = useState({ name: "", category: "", phone: "" });

  const handleAdd = () => {
    if (newItem.name && newItem.category) {
      setListings([...listings, newItem]);
      setNewItem({ name: "", category: "", phone: "" });
    }
  };

  const filtered = listings.filter(item =>
    item.name.toLowerCase().includes(search.toLowerCase()) ||
    item.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h1>Barlekha City Directory</h1>
      <input
        type="text"
        placeholder="Search..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ padding: 8, width: "100%", marginBottom: 16 }}
      />
      <ul>
        {filtered.map((item, idx) => (
          <li key={idx}>
            <strong>{item.name}</strong> — {item.category} — 📞 {item.phone}
          </li>
        ))}
      </ul>
      <h2>Add New</h2>
      <input
        placeholder="Name"
        value={newItem.name}
        onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
        style={{ padding: 6, marginRight: 8 }}
      />
      <input
        placeholder="Category"
        value={newItem.category}
        onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
        style={{ padding: 6, marginRight: 8 }}
      />
      <input
        placeholder="Phone"
        value={newItem.phone}
        onChange={(e) => setNewItem({ ...newItem, phone: e.target.value })}
        style={{ padding: 6, marginRight: 8 }}
      />
      <button onClick={handleAdd} style={{ padding: 6 }}>Add</button>
    </div>
  );
}
